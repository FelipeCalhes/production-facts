sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("mesinterface.mesinterface.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);