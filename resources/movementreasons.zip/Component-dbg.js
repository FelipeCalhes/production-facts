sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("movementreasons.movementreasons.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);